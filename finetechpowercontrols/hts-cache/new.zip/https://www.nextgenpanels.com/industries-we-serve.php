<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Electrical Control Panel Manufacturer - Nextgen power controls</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="shortcut icon" type="image/x-icon" href="assets/favicon.png"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload stylesheet" as="style" href="https://fonts.googleapis.com/css2?family=Anton&family=Mulish:wght@300&family=Saira+Semi+Condensed:wght@400;500;600;700;800&display=swap">
    <link rel="preload stylesheet" as="style" href="assets/css/bootstrap.min.css">
    <link rel="preload stylesheet" as="style" href="assets/css/custom-bootstrap.css">
    <link rel="preload stylesheet" as="style" href="assets/css/animate.min.css">
    <link rel="preload stylesheet" as="style" href="assets/css/custom-animation.css">
    <link rel="preload stylesheet" as="style" href="assets/css/fontawesome.min.css">
    <link rel="preload stylesheet" as="style" href="assets/css/meanmenu.css">
    <link rel="preload stylesheet" as="style" href="assets/css/flaticon.css">
    <link rel="preload stylesheet" as="style" href="assets/css/nice-select.css">
    <link rel="preload stylesheet" as="style" href="assets/css/venobox.min.css">
    <link rel="preload stylesheet" as="style" href="assets/css/backToTop.css">
    <link rel="preload stylesheet" as="style" href="assets/css/slick.css">
    <link rel="preload stylesheet" as="style" href="assets/css/owl.carousel.min.css">
    <link rel="preload stylesheet" as="style" href="assets/css/swiper-bundle.css">
    <link rel="preload stylesheet" as="style" href="assets/css/default.css">
    <link rel="preload stylesheet" as="style" href="assets/css/main.css">
    <link rel="preload stylesheet" as="style" href="assets/css/model-custom.css">
    <link rel="preload stylesheet" as="style" href="assets/css/sidebar-btn.css">
    <link rel='preload stylesheet' as="style" href='https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.4/jquery.fancybox.css'>

    <link rel="preload" fetchpriority="high" as="image" href="" type="image/jpg">

    <!-- Google Tag Manager -->
    <script>
    (function(w, d, s, l, i) {
        w[l] = w[l] || [];
        w[l].push({
            'gtm.start': new Date().getTime(),
            event: 'gtm.js'
        });
        var f = d.getElementsByTagName(s)[0],
            j = d.createElement(s),
            dl = l != 'dataLayer' ? '&l=' + l : '';
        j.async = true;
        j.src =
            'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
        f.parentNode.insertBefore(j, f);
    })(window, document, 'script', 'dataLayer', 'GTM-54KT423');
    </script>
    <!-- End Google Tag Manager -->
    <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    </script>
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-54KT423" height="0" width="0"
            style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->
    <div class="sticklist">
    <input type="hidden" id="ismobile" value="0">
    <button class="open-close-arrow">
        <span class="open-arrow"><i class="fa fa-chevron-right"></i></span>
        <span class="close-arrow"><i class="fa fa-chevron-left"></i></span>
    </button>
    <ul>
        <li class="none-li inquiery-icon  imgnone">
            <a href="javascript:;" class="click1">
                <span class="icon1"> <i class="fa fa-envelope"></i></span> <span class="btn-text"> Send Inquiry</span>
            </a>
        </li>
        <li class="download-pdf none-li inquiery-icon  imgnone">
            <a pdf="pdf/NGPC-COMPANY-PROFILE.pdf" href="javascript:;" class="click2">
                <span class="icon"> <i class="fa fa-file-pdf"></i></span> <span class="btn-text">Catalogue</span>
            </a>
        </li>
        <li class="none-li inquiery-icon  imgnone">
            <a href="tel:+91 95861 18114"
                onclick="gtag('event', 'send', { 'event_category': 'click on Mobile', 'event_action': 'Mobile', 'event_label': '+91 95861 18114' });">
                <span class="icon"> <i class="fa fa-phone-alt"></i></span> <span class="btn-text">Call</span>
            </a>
        </li>
        <li class="whataspp-icon none-li imgnone">
      <a onclick="gtag('event', 'send', { 'event_category': 'click on whatsapp', 'event_action': 'Mobile', 'event_label': '+919537518114' });" href="https://api.whatsapp.com/send?phone=919537518114&amp;text=Hello Team Next-Gen Power Controls, I was going through your website and wish to get connected for product discussion



" target="_blank">
        <span class="icon1"> <i class="fab fa-whatsapp"></i></span> <span class="btn-text"> Whatsapp</span></a>
    </li>

    </ul>
</div>
<div class="modal fade bs-example-modal-sm cstm-modal-top-header my-custom-modal" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true" id="onload">
    <div class="modal-dialog modal-lg">
        <input type="hidden" id="ispopupopen" value="1">
        <div class="modal-content">
            <div class="modal-body stick_popup">
                <h5 class="modal-title">Get Your Free Quote…!</h5>
                <div class="stick_close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></div>
                <div class="row mt-40">
                    <div class="col-md-5 col-sm-12 col-xs-12 px-0">
                        <div class="logo-wrapper">
                            <img src="assets/img/logo.png">
                            <button class="btn-modal-gra">
                                <a class="content-p" href="mailto:sales@nextgenpanels.com"
                                    onclick="gtag('event', 'send', { 'event_category': 'click on mail', 'event_action': 'mailto', 'event_label': 'sales@nextgenpanels.com' });"><b>sales@nextgenpanels.com</b></a>
                                <br> <a class="content-p" href="tel:+91 95861 18114"
                                    onclick="gtag('event', 'send', { 'event_category': 'click on Mobile', 'event_action': 'Mobile', 'event_label': '+91 95861 18114' });">
                                    <b>+91 95861 18114</b>
                                </a>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-12 col-xs-12">


                        <div class="footer-widgets tag-widget">
                            <input id="inquiery-model" value="" type="hidden" />
                            <input id="isloadopenmodel" value="" type="hidden" />

                            <input name="junk_trap" class="junk_trap" type="hidden" />

                            <form class="form-horizontal form1" action="inquiry-action.php" method="post"
                                novalidate="novalidate">
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <input name="name" id="name" type="text" placeholder="Name"
                                            class="form-control">

                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <input name="email" id="email" type="text" placeholder="E-Mail Address"
                                            class="form-control">

                                    </div>
                                </div>
                                <div class="form-group has-feedback class-feedback">
                                    <div class="col-md-12">
                                        <input name="city" id="city" type="text" placeholder="City"
                                            class="form-control">

                                    </div>

                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <input name="number" id="number" type="tel" placeholder="Phone" maxlength="15"
                                            minlength="10" class="form-control number21">

                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <textarea class="form-control" name="message" id="message"
                                            placeholder="Requirement"></textarea>

                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-8 col position-relative">
                                                <input name="captcha" id="captcha" placeholder="Captcha Code"
                                                    class="form-control" type="text">

                                            </div>
                                            <div class="col-md-4 col">
                                                <img src="captcha.php" class="capside">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12 col-sm-3 col-xs-12">
                                        <input name="submit" class="submit submitbutton" type="submit"
                                            value="Submit Now!">
                                    </div>
                                </div>
                            </form>

                        </div>

                    </div>

                </div>

            </div>

            <div class="clearfix"></div>

        </div>

        <div class="clearfix"></div>

    </div>

    <div class="clearfix"></div>

</div>

<!-- End My Model -->

<!-- catelog model -->
<div class="modal fade bs-example-modal-sm cstm-modal-top-header my-custom-modal" tabindex="-1" role="dialog"
    aria-labelledby="myLargeModalLabel" aria-hidden="true" id="onload1">
    <div class="modal-dialog modal-sm">

        <div class="modal-content">

            <div class="modal-body ">
                <h5 class="modal-title">Catalogue Request Form…!</h5>
                <div class="stick_close" data-bs-dismiss="modal" aria-label="Close"><i class="fa fa-times"></i></div>
                <div class="row mt-40">
                    <div class="col-md-5 col-sm-12 col-xs-12 px-0">
                        <div class="logo-wrapper">
                            <img src="assets/img/logo.png">
                            <button class="btn-modal-gra">
                                <a class="content-p" href="mailto:sales@nextgenpanels.com"
                                    onclick="gtag('event', 'send', { 'event_category': 'click on mail', 'event_action': 'mailto', 'event_label': 'sales@nextgenpanels.com' });"><b>sales@nextgenpanels.com</b></a>
                                <br> <a class="content-p" href="tel:+91 95861 18114"
                                    onclick="gtag('event', 'send', { 'event_category': 'click on Mobile', 'event_action': 'Mobile', 'event_label': '+91 95861 18114' });"><b>+91 95861 18114                                    </b></a>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-7 col-sm-7 col-xs-12 ">
                        <div class=" footer-widgets tag-widget formtop">
                            <form class="form-horizontal form2" action="catalogue-action.php" method="post">
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <input name="name" id="name2" type="text" placeholder="Name"
                                            class="form-control">

                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <input name="email" id="email2" type="text" placeholder="E-Mail Address"
                                            class="form-control">

                                    </div>
                                </div>
                                <div class="form-group has-feedback class-feedback">
                                    <div class="col-md-12">
                                        <input name="city" id="city" type="text" placeholder="City"
                                            class="form-control">

                                    </div>

                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <input name="number" id="number2" type="tel" placeholder="Phone" maxlength="10"
                                            minlength="10" class="form-control number21">

                                    </div>
                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12">
                                        <div class="row">
                                            <div class="col-md-8 position-relative">
                                                <input name="captcha" id="captcha2" placeholder="Captcha Code"
                                                    class="form-control" type="text">

                                            </div>
                                            <div class="col-md-4">
                                                <img src="captcha.php" class="capside">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">

                                    <div class="col-md-8 inputGroupContainer">
                                        <div class="input-group inline4">
                                            <input type="hidden" id="pt" name="path" value="">
                                        </div>
                                    </div>

                                </div>
                                <div class="form-group has-feedback">
                                    <div class="col-md-12 col-sm-3 col-xs-12">
                                        <input name="submit2" id="submit2" class="submit submitbutton" type="submit"
                                            value="Download Now">
                                    </div>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end catelog model -->

<div class="footer-box" style="display: none;">
    <div class="book-app" style="background:#ff8230;" id="req-apnmt2">
        <a class="nav_up click1" href="javascript:;" style="color:#FFF; font-size:12px;font-weight:600;"><i
                class="fa fa-envelope" style="margin-right: 5px;"></i> Enquire Now</a>
    </div>
    <div class="book-app" style="background: #444a53;">
        <a class="nav_up click2" pdf="pdf/NGPC-COMPANY-PROFILE.pdf" href="javascript:;"
            style="color:#FFF; font-size:12px;font-weight:600;"><i class="fa fa-file-pdf-o"
                style="margin-right: 5px;"></i> Catalogue</a>
    </div>
    <div class="book-app" style="background: #2db640;">
    <a onclick="gtag('event', 'send', { 'event_category': 'click on whatsapp', 'event_action': 'Mobile', 'event_label': '+919537518114' });" href="https://api.whatsapp.com/send?phone=919537518114&amp;text=Hello Team Next-Gen Power Controls, I was going through your website and wish to get connected for product discussion



"  target="_blank" style="color:#FFF; font-size:12px;font-weight:600;"><i class="fab fa-whatsapp" style="margin-right: 5px;"></i> Whatsapp</a>
  </div>
</div>


<!-- End My Model -->

    <div class="progress-wrap">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
        </svg>
    </div>
    <header class="header-area">
        <div class="mheader-top theme-bg-blue">
            <div class="custom-container">
                <div class="row align-items-center">
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="header-top-left">
                            <span>Follow us:</span>
                            <a href="https://www.facebook.com/pg/Next-Gen-POWER-Controls-911267245694297/posts/"
                                target="_blank"><i class="fab fa-facebook-f"></i></a>
                            <a href="javascript:;" target="_blank"><i class="fab fa-twitter"></i></a>
                            <a href="https://in.linkedin.com/in/sanjay-patel-7357461a2" target="_blank"><i
                                    class="fab fa-linkedin-in"></i></a>
                            <a href="https://www.instagram.com/sanjaypatel71087/" target="_blank"><i
                                    class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                    <div class="col-xl-5 col-lg-5 col-md-5 d-none d-lg-block">
                        <div class="topbar-text text-center">
                            <p>Leading Electrical Control Panel Manufacturer</p>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6">
                        <div class="topbar-right">
                            <span><i class="fa fa-envelope-open" style="margin-right: 5px;"></i></span>
                            <a style="margin-right: 15px;" href="mailto:sales@nextgenpanels.com"
                                onclick="gtag('event', 'send', { 'event_category': 'click on mail', 'event_action': 'mailto', 'event_label': 'sales@nextgenpanels.com' });">
                                sales@nextgenpanels.com</a>
                            <span><i class="fa fa-phone" style="transform: rotate(90deg);margin-right: 5px;"></i></span>
                            <a href="tel:+919586118114"
                                onclick="gtag('event', 'send', { 'event_category': 'click on Mobile', 'event_action': 'Mobile', 'event_label': '+919586118114' });">
                                +91 95861 18114</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="header-menu header-sticky">
            <div class="custom-container">
                <div class="row align-items-center">
                    <div class="col-xxl-2 col-xl-2 col-lg-2 col">
                        <div class="header-logo ">
                            <a href="index.php"><img src="assets/img/logo.png" class="img-fluid" alt="img"></a>
                        </div>
                    </div>
                    <div class="col-xxl-10 col-xl-10 col-lg-10 col">

                        <div class="main-menu main-menu-3 d-none d-lg-block" id="white-menu">
                            <nav id="mobile-menu">
                                <ul>
                                    <li><a href="index.php">Home</a></li>
                                    <li><a href="about-us.php">About Us</a></li>
                                    <li class="has-dropdown"><a href="our-products.php">Our Products</a>
                                        <!-- <ul class="submenu">
                                            <li><a href="power-control-center-pcc-panels.php">Power Control Center (PCC) Panels</a></li>
                                            <li><a href="motor-control-center-mcc-panel.php">Motor Control Center (MCC) Panel</a></li>
                                            <li><a href="automatic-power-factor-correction-panels.php">Automatic Power Factor Correction Panels</a></li>
                                            <li><a href="synchronizing-and-auto-load-sharing-panel.php">Synchronizing and Auto Load Sharing Panel</a></li>
                                            <li><a href="automatic-mains-failure-amf-panel.php">Automatic Mains Failure (AMF) Panel</a></li>
                                            <li><a href="power-factor-control-panels.php">Power Factor Control Panels</a></li>
                                            <li><a href="dg-set-control-panels.php">DG Set Control Panels</a></li>
                                            <li><a href="power-distribution-panels.php">Power Distribution Panels</a></li>
                                            <li><a href="low-tension-control-panels.php">Low Tension Control Panels</a></li>
                                            <li><a href="dg-synchronization-panels.php">DG Synchronization Panels</a></li>
                                            <li><a href="power-control-center-panel-boards.php">Power Control Center Panel Boards</a></li>
                                            <li><a href="fire-hydrant-control-panel.php">Fire Hydrant Control Panel</a></li>
                                            <li><a href="vfd-based-control-panel.php">VFD Based Control Panel</a></li>
                                            <li><a href="feeder-pillar-panel.php">Feeder Pillar Panel</a></li>
                                            <li><a href="gi-cable-tray.php">Gi Cable Tray</a></li>
                                        </ul> -->
                                    </li>
                                    <li><a href="certificate.php">Certificate</a></li>
                                    <li><a href="industries-we-serve.php">Industries We Serve</a></li>
                                    <!-- <li><a href="javascript:;">Case Studies</a></li>
                                    <li><a href="javascript:;">Special Cases</a></li>
                                    <li><a href="javascript:;">News & Events</a></li> -->
                                    <li><a href="gallery.php">Gallery</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </nav>
                        </div>
                        <div class="header__action-item d-lg-none d-flex align-items-center justify-content-end">
                            <a href="javascript:void(0)" class="sidebar-toggle">
                                <span></span>
                                <span></span>
                                <span></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <div class="offcanvas-overlay"></div>

    <div class="sidebar__area">
        <div class="sidebar__wrapper">
            <div class="sidebar__top d-flex align-items-center mb-40">
                <div class="sidebar__close mr-35">
                    <button class="sidebar__close-btn sidebar-close">
                        <svg viewBox="0 0 22 22">
                            <path d="M12.41,11l5.29-5.29c0.39-0.39,0.39-1.02,0-1.41s-1.02-0.39-1.41,0L11,9.59L5.71,4.29c-0.39-0.39-1.02-0.39-1.41,0
                            s-0.39,1.02,0,1.41L9.59,11l-5.29,5.29c-0.39,0.39-0.39,1.02,0,1.41C4.49,17.9,4.74,18,5,18s0.51-0.1,0.71-0.29L11,12.41l5.29,5.29
                            C16.49,17.9,16.74,18,17,18s0.51-0.1,0.71-0.29c0.39-0.39,0.39-1.02,0-1.41L12.41,11z" />
                        </svg>
                    </button>
                </div>
                <div class="logo">
                    <a href="index.html">
                        <img src="assets/img/logo.png" alt="logo">
                    </a>
                </div>
            </div>
            <div class="sidebar__content p-relative z-index-1">
                <div class="sidebar__menu">
                    <div class="mobile-menu"></div>
                </div>
            </div>
        </div>
    </div>
<main>
   <section class="default-hero">
      <img src="assets/img/breadcums/industries.jpg" alt="">
      <div class="page-name-wrapper wow slideInLeft" data-wow-delay="0.3s" style="visibility: visible; animation-delay: 0.3s; animation-name: slideInLeft;">
         <h1>Industries We Serve</h1>
      </div>
   </section>
   <section class="tp-contact-area pt-50 pb-50">
      <div class="container">
         <div class="row">
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/chemical.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Chemical Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/mining.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Mining Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/oil-&-gas.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Oil & Gas Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/pharmaceuticals.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Pharmaceutical Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/power-plant.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Power Plant Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/solar.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Solar Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/steel.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Steel Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/textile.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Textile Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
            <div class="service-block-two col-lg-4 col-md-6 col-sm-12">
               <div class="inner-box">
                  <div class="image">
                     <img src="assets/img/inner-industries-we-serve/petroleum.jpg" alt="">
                  </div>
                  <div class="lower-box">
                     <div class="box-inner">
                        <h6>Petroleum Industries</h6>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
</main>
<footer id="footer" style="clear: both;">
    <nav class="footer-top">
        <div class="ui stackable equal width grid">
            <div class="column">
                <h3>QUICK LINKS</h3>
                <a href="index.php"><i class="fa fa-angle-double-right"></i> Home</a>
                <a href="about-us.php"><i class="fa fa-angle-double-right"></i> About Us</a>
                <a href="our-products.php"><i class="fa fa-angle-double-right"></i> Our Products</a>
                <a href="certificate.php"><i class="fa fa-angle-double-right"></i> Certificate</a>
                <a href="industries-we-serve.php"><i class="fa fa-angle-double-right"></i> Industries We Serve</a>
                <a href="gallery.php"><i class="fa fa-angle-double-right"></i> Gallery</a>
                <a href="contact.php"><i class="fa fa-angle-double-right"></i> Contact</a>

                <img src="assets/img/make-in-india.webp" class="img-fluid mt-5" />
            </div>
            <div class="column">
                <h3>PRODUCTS</h3>
                <a href="power-control-center-pcc-panels.php"><i class="fa fa-angle-double-right"></i> Power Control
                    Center (PCC) Panels</a>
                <a href="motor-control-center-mcc-panel.php"><i class="fa fa-angle-double-right"></i> Motor Control
                    Center (MCC) Panel</a>
                <a href="automatic-power-factor-correction-panels.php"><i class="fa fa-angle-double-right"></i>
                    Automatic Power Factor Correction Panels</a>
                <a href="synchronizing-and-auto-load-sharing-panel.php"><i class="fa fa-angle-double-right"></i>
                    Synchronizing & Auto Load Sharing Panel</a>
                <a href="automatic-mains-failure-amf-panel.php"><i class="fa fa-angle-double-right"></i> Automatic Mains
                    Failure (AMF) Panel</a>
                <a href="power-factor-control-panels.php"><i class="fa fa-angle-double-right"></i> Power Factor Control
                    Panels</a>
                <a href="dg-set-control-panels.php"><i class="fa fa-angle-double-right"></i> DG Set Control Panels</a>
            </div>
            <div class="column">
                <h3>CONTACT</h3>
                <span style="margin-bottom: 10px; display: block;"><strong class="font-f">Next-Gen Power
                        Controls</strong></span><span><strong class="font-f">Corporate Office</strong></span> <a
                    href="javascript:;" class="address-icon"
                    style="margin-bottom: 10px; display: block;pointer-events: none;">
                    8, Rashmi Growth Hub Ind. Estate, <br>Opp. Vijay Sales Showroom, <br>Nr. Shivkunj Exortica, <br>S.P.
                    Ring Road, Odhav,<br>Ahmedabad - 382415
                </a> <a href="tel:+919586118114"
                    onclick="gtag('event', 'send', { 'event_category': 'click on Mobile', 'event_action': 'Mobile', 'event_label': '+919586118114' });"
                    class="phone-icon" style="margin-bottom: 10px; display: block;"> +91 95861 18114</a> <a
                    href="mailto:sales@nextgenpanels.com"
                    onclick="gtag('event', 'send', { 'event_category': 'click on mail', 'event_action': 'mailto', 'event_label': 'sales@nextgenpanels.com' });"
                    class="mail-icon"> sales@nextgenpanels.com</a>
            </div>
            <div class="column my-custom-modal">
                <h3>GET QUOTE</h3>
                <form class="form-horizontal form3" action="inquiry-action.php" method="post" novalidate="novalidate">
                    <div class="form-group has-feedback">
                        <div class="col-md-12">
                            <input name="name" id="name" type="text" placeholder="Name" class="form-control">

                        </div>
                    </div>
                    <div class="form-group has-feedback">
                        <div class="col-md-12">
                            <input name="email" id="email" type="text" placeholder="E-Mail Address"
                                class="form-control">

                        </div>
                    </div>
                    <div class="form-group has-feedback class-feedback">
                        <div class="col-md-12">
                            <input name="city" id="city" type="text" placeholder="City" class="form-control">

                        </div>

                    </div>
                    <div class="form-group has-feedback">
                        <div class="col-md-12">
                            <input name="number" id="number" type="tel" placeholder="Phone" maxlength="15"
                                minlength="10" class="form-control number21">

                        </div>
                    </div>
                    <div class="form-group has-feedback">
                        <div class="col-md-12">
                            <textarea class="form-control" name="message" id="message"
                                placeholder="Requirement"></textarea>

                        </div>
                    </div>
                    <div class="form-group has-feedback">
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-8 col position-relative">
                                    <input name="captcha" id="captcha" placeholder="Captcha Code" class="form-control"
                                        type="text">

                                </div>
                                <div class="col-md-4 col">
                                    <img src="captcha.php" class="capside">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group has-feedback">
                        <div class="col-md-12 col-sm-3 col-xs-12">
                            <input name="submit" class="submit submitbutton" type="submit" value="Submit Now!">
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <!-- <div class="footer-logo-mindia"><img src="images/make-in-india.png" alt=""></div> -->
    </nav>
    <div class="footer-bottom">
        <div class="socialRow">
            <ul class="list-inline mb-0 socialListing text-center">
                <li class="list-inline-item"><a
                        href="https://www.facebook.com/pg/Next-Gen-POWER-Controls-911267245694297/posts/"
                        target="_blank" class="scl-item"><i class="icon fab fa-facebook-f"></i></a></li>
                <li class="list-inline-item"><a href="javascript:;" target="_blank" class="scl-item"><i
                            class="icon fab fa-twitter"></i></a></li>
                <li class="list-inline-item"><a href="javascript:;" target="_blank" class="scl-item"><i
                            class="icon fab fa-linkedin"></i></a></li>
                <li class="list-inline-item"><a href="https://www.instagram.com/sanjaypatel71087/" target="_blank"
                        class="scl-item"><i class="icon fab fa-instagram"></i></a></li>
            </ul>
        </div>
        <p>Copyright © 2025 Next-Gen Power Controls. All rights reserved.</p>
    </div>
</footer>
<script src="assets/js/jquery-1.12.4.min.js"></script>
<script src="assets/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/isotope.pkgd.min.js"></script>
<script src="assets/js/slick.min.js"></script>
<script src="assets/js/swiper-bundle.js"></script>
<script src="assets/js/waypoints.min.js"></script>
<script src="assets/js/jquery.nice-select.min.js"></script>
<script src="assets/js/venobox.min.js"></script>
<script src="assets/js/backToTop.js"></script>
<script src="assets/js/jquery.meanmenu.min.js"></script>
<script src="assets/js/imagesloaded.pkgd.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/jquery.counterup.min.js"></script>
<script src="assets/js/wow.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/index.js"></script>
<script src="assets/js/jquery.validate.min.js"></script>
<script src="assets/js/form-buzz.js"></script>
<script src='https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.4/jquery.fancybox.pack.js'></script>
<script>
var tpj2 = jQuery;

tpj2.noConflict();
tpj2(document).ready(function() {
    tpj2("a.fancybox").fancybox()
});
</script>
<script>
var tpj2 = jQuery;

tpj2.noConflict();
tpj2(document).ready(function() {
    //FANCYBOX
    //https://github.com/fancyapps/fancyBox
    tpj2(".fancybox").fancybox({
        openEffect: 'elastic',
        closeEffect: "elastic",
    });
});
</script>
<script type="text/javascript">
var tpj2 = jQuery;

tpj2.noConflict();
tpj2('.counter').counterUp({
    delay: 10,
    time: 2000
});
tpj2('.counter').addClass('animated fadeInDownBig');
</script>
</body>

</html>
